def show_employee(name: str, salary: int = 100000) -> str:
    return f"{name}: {salary} ₽"