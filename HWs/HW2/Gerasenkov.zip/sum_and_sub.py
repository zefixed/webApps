def sum_and_sub(a: int, b: int) -> list[int]:
    return [a + b, a - b]