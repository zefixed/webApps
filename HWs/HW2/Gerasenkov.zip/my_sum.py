def my_sum(*args: list[float]) -> int:
    return float(sum(*args))
